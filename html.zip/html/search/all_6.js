var searchData=
[
  ['hasetiqueta',['hasEtiqueta',['../class_tarea.html#a0d81aaf4fd8ce31234b75ba2af02c3e6',1,'Tarea']]],
  ['hora',['hora',['../class_comanda.html#ae8bca2ad702d3316dc1c53dcab7cac02',1,'Comanda']]]
];
