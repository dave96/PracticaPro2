var searchData=
[
  ['tarea',['Tarea',['../class_tarea.html',1,'Tarea'],['../class_tarea.html#ae6b34d434fe9ccf25887e2a15130ce24',1,'Tarea::Tarea()']]],
  ['tarea_2ecc',['tarea.cc',['../tarea_8cc.html',1,'']]],
  ['tarea_2ehh',['tarea.hh',['../tarea_8hh.html',1,'']]],
  ['tasca',['tasca',['../class_comanda.html#a67591051e9c5977c324ad8f8c3ac16e3',1,'Comanda']]],
  ['te_5fexpressio',['te_expressio',['../class_comanda.html#a81d17f4233e33f3baac7633546c066f0',1,'Comanda']]],
  ['te_5fhora',['te_hora',['../class_comanda.html#abf8b926146f3664aacfd24d7800014e5',1,'Comanda']]],
  ['te_5ftitol',['te_titol',['../class_comanda.html#a5452f5a877d58627cd2bd871cf31b074',1,'Comanda']]],
  ['tieneexpresion',['tieneExpresion',['../class_tarea.html#a55f3abf6f76b3d47f57c1ef9d3a5398f',1,'Tarea']]],
  ['tipus_5fesborrat',['tipus_esborrat',['../class_comanda.html#a998dc172668a108837512f818ca5430f',1,'Comanda::tipus_esborrat()'],['../class_token.html#a12c961c772aa760b719dc3becb523ac4',1,'Token::tipus_esborrat()']]],
  ['titol',['titol',['../class_comanda.html#ad1cefdda3db389d9ab536a59e2ee907d',1,'Comanda']]],
  ['token',['Token',['../class_token.html',1,'Token'],['../class_token.html#aa3c5868ba4115f3189df6b2ac5b36f39',1,'Token::Token()'],['../class_token.html#a2ecb0099476455ed7ce3c05abcbb2e31',1,'Token::Token(const string &amp;s, bool &amp;be)']]],
  ['token_2ecc',['token.cc',['../token_8cc.html',1,'']]],
  ['token_2ehh',['token.hh',['../token_8hh.html',1,'']]]
];
