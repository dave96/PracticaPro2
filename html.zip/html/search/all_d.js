var searchData=
[
  ['setdia',['setDia',['../class_fecha.html#ad90318afb47e6f0531d2be63859be15d',1,'Fecha']]],
  ['sethora',['setHora',['../class_fecha.html#ad85488747a718072f431c46c2aac98df',1,'Fecha']]],
  ['settitle',['setTitle',['../class_tarea.html#a890c87bed11a8d78fab9ff9143a4c9c7',1,'Tarea']]]
];
