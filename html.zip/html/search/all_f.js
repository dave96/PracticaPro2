var searchData=
[
  ['update',['update',['../class_reloj.html#a8dbcf340ecbcf3f119f50752a2458965',1,'Reloj']]]
];
