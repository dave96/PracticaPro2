var searchData=
[
  ['data',['data',['../class_comanda.html#ab4ce0a50bde32145d11cbaee753526c7',1,'Comanda']]],
  ['deleteetiqueta',['deleteEtiqueta',['../class_tarea.html#abab3eb90ace416938a14c25471588dd3',1,'Tarea']]],
  ['deleteetiquetas',['deleteEtiquetas',['../class_tarea.html#a30b3b4e3bbb67815511ed0c37f67b8af',1,'Tarea']]]
];
