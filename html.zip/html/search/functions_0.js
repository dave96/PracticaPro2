var searchData=
[
  ['addetiqueta',['addEtiqueta',['../class_tarea.html#a2d434fcc980267cdc1e7ff453befbf20',1,'Tarea']]],
  ['agenda',['Agenda',['../class_agenda.html#a6685054d2b4ccbf2a4ef2ac5e3746bc3',1,'Agenda']]],
  ['anadirtarea',['anadirTarea',['../class_menu.html#acbd4248be19b8583ca323c20cf803e5d',1,'Menu']]]
];
