var searchData=
[
  ['getdia',['getDia',['../class_fecha.html#a85d32f9b862736517d375b316d08167b',1,'Fecha']]],
  ['getfecha',['getFecha',['../class_reloj.html#a6340b1f87a4448c31719088ea23076f1',1,'Reloj']]],
  ['gethora',['getHora',['../class_fecha.html#a9c68e70d6b8090ceae5a386001dd2dff',1,'Fecha']]]
];
