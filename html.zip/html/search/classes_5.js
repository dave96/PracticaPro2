var searchData=
[
  ['tarea',['Tarea',['../class_tarea.html',1,'']]],
  ['token',['Token',['../class_token.html',1,'']]]
];
