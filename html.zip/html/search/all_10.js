var searchData=
[
  ['write',['write',['../class_fecha.html#a566d149255eb0e0131844547bfd04160',1,'Fecha::write()'],['../class_reloj.html#af609aab058a8f1be0872c86f8dfb8532',1,'Reloj::write()'],['../class_tarea.html#ad83173d2aa5e16c02425dbb2e2a8a5b8',1,'Tarea::write()']]],
  ['writeetiquetas',['writeEtiquetas',['../class_tarea.html#add5135bb1c2c57f5ff38f8887f63012f',1,'Tarea']]]
];
